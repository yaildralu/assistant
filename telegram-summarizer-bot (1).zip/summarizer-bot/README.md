# Telegram Summarizer Bot (Node.js, tanpa API key AI)

Bot ini meringkas artikel (link), teks panjang, diskusi grup, dan file PDF.
Ringkasan dibuat dengan algoritma TextRank lokal sehingga tidak memerlukan API key AI apa pun.

## Fitur
| Perintah | Fungsi |
|---|---|
| `/ringkas <url>` | Ringkas artikel dari link (HTML atau PDF online) |
| `/ringkas <teks>` | Ringkas teks panjang |
| `/ringkas` (reply) | Ringkas pesan/PDF yang dibalas |
| `/diskusi <teks>` | Ringkas diskusi grup, lengkap dengan topik dan peserta aktif |
| Kirim PDF + caption `/ringkas` | Ringkas file PDF |
| Tambahan `-n 3` | Atur jumlah kalimat ringkasan (1 sampai 15) |

## Persyaratan
- Node.js 18 atau lebih baru
- Token bot dari @BotFather

## Instalasi di Panel (Pterodactyl / panel Node.js lain)
1. Upload file ZIP ini lalu extract.
2. Isi token bot. Ada dua cara:
   - Tambahkan variabel `BOT_TOKEN` di menu Startup/Environment panel, atau
   - Salin `.env.example` menjadi `.env` lalu isi `BOT_TOKEN`.
3. Jalankan `npm install` (di Console panel, atau otomatis jika panel mendukung).
4. Atur startup command: `npm start` atau `node index.js`.
5. Start server. Pastikan muncul pesan "Bot summarizer berjalan".

## Catatan untuk grup
- Tambahkan bot ke grup sebagai member. Perintah `/ringkas` dan `/diskusi` langsung berfungsi.
- Untuk ringkasan diskusi, salin percakapan grup lalu kirim dengan `/diskusi`, atau balas (reply) sebuah pesan.
  Format "Nama: pesan" paling akurat.

## Batasan
- Metode ekstraktif memilih kalimat penting dari teks asli. Hasilnya tidak selalu sefasih ringkasan AI.
- PDF hasil scan (gambar) tidak bisa dibaca karena tidak ada OCR.
- Ukuran file Telegram untuk bot maksimal 20 MB.
