require('dotenv').config();
const { Telegraf } = require('telegraf');
const { fetchArticle, pdfBufferToText, downloadTelegramFile } = require('./lib/extract');
const { summarize, summarizeDiscussion } = require('./lib/summarizer');

const BOT_TOKEN = process.env.BOT_TOKEN;
if (!BOT_TOKEN || BOT_TOKEN.startsWith('isi_token')) {
  console.error('[ERROR] BOT_TOKEN belum diatur. Isi di Startup Variables panel atau file .env');
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);
const TG_LIMIT = 3900;

const HELP = `🤖 Bot Peringkas (tanpa API key AI)

Perintah:
/ringkas <url> — ringkas artikel dari link (termasuk PDF online)
/ringkas <teks> — ringkas teks panjang
/ringkas — balas (reply) sebuah pesan/PDF untuk meringkasnya
/diskusi <teks> — ringkas diskusi grup (bisa juga reply pesan)
Kirim file PDF dengan caption /ringkas untuk meringkas PDF

Opsi jumlah kalimat: tambahkan -n 3 (1 sampai 15)
Contoh: /ringkas https://contoh.com/artikel -n 4`;

/** Membaca opsi -n dan mengembalikan sisa teks */
function parseOptions(text = '') {
  const body = text.replace(/^\/\w+(@\w+)?\s*/, '');
  const m = body.match(/(?:^|\s)-n\s+(\d{1,2})\b/);
  let n = 5;
  let rest = body;
  if (m) {
    n = Math.min(Math.max(parseInt(m[1], 10), 1), 15);
    rest = body.replace(m[0], ' ');
  }
  return { body: rest.trim(), n };
}

/** Kirim pesan panjang dengan memecahnya per baris agar tidak melebihi batas Telegram */
async function sendLong(ctx, text) {
  let chunk = '';
  for (const line of text.split('\n')) {
    if ((chunk + '\n' + line).length > TG_LIMIT) {
      await ctx.reply(chunk.trim());
      chunk = line;
    } else {
      chunk += '\n' + line;
    }
  }
  if (chunk.trim()) await ctx.reply(chunk.trim());
}

function formatArticle(title, summary, originalLength) {
  const head = title ? `📰 ${title}\n\n` : '';
  const ratio = originalLength ? ` (dari ${originalLength.toLocaleString('id-ID')} karakter)` : '';
  return `${head}📝 Ringkasan${ratio}:\n\n${summary}`;
}

async function summarizeUrl(ctx, url, n) {
  await ctx.sendChatAction('typing');
  try {
    const { title, text } = await fetchArticle(url);
    const summary = summarize(text, n);
    if (!summary) return ctx.reply('❌ Tidak ada teks yang bisa diringkas dari halaman tersebut.');
    await sendLong(ctx, formatArticle(title, summary, text.length));
  } catch (err) {
    console.error('[URL]', err.message);
    await ctx.reply(`❌ Gagal meringkas link: ${err.message}`);
  }
}

async function summarizeText(ctx, text, n) {
  const summary = summarize(text, n);
  if (!summary) return ctx.reply('❌ Teks terlalu pendek untuk diringkas.');
  await sendLong(ctx, `📝 Ringkasan:\n\n${summary}`);
}

async function summarizeDocument(ctx, doc, n) {
  const isPdf =
    (doc.mime_type || '').includes('pdf') || (doc.file_name || '').toLowerCase().endsWith('.pdf');
  if (!isPdf) return ctx.reply('❌ File harus berformat PDF.');
  if (doc.file_size > 20 * 1024 * 1024) return ctx.reply('❌ File terlalu besar (maks 20 MB untuk bot).');

  await ctx.sendChatAction('upload_document');
  try {
    const buf = await downloadTelegramFile(ctx, doc.file_id);
    const text = await pdfBufferToText(buf);
    const summary = summarize(text, n);
    if (!summary) return ctx.reply('❌ Tidak ada teks yang bisa dibaca di PDF ini (mungkin hasil scan).');
    await sendLong(ctx, formatArticle(doc.file_name, summary, text.length));
  } catch (err) {
    console.error('[PDF]', err.message);
    await ctx.reply(`❌ Gagal memproses PDF: ${err.message}`);
  }
}

async function summarizeDiscussionCmd(ctx, text, n) {
  const { summary, keywords, topSpeakers, totalMessages } = summarizeDiscussion(text, n);
  if (!summary) return ctx.reply('❌ Diskusi terlalu pendek untuk diringkas.');

  const lines = [`💬 Ringkasan Diskusi (${totalMessages} pesan)`, ''];
  if (keywords.length) lines.push(`🏷 Topik utama: ${keywords.join(', ')}`);
  if (topSpeakers.length) {
    lines.push(`👥 Peserta aktif: ${topSpeakers.map(([nm, c]) => `${nm} (${c})`).join(', ')}`);
  }
  lines.push('', summary);
  await sendLong(ctx, lines.join('\n'));
}

bot.start(ctx => ctx.reply(HELP));
bot.help(ctx => ctx.reply(HELP));

bot.command('ringkas', async ctx => {
  const { body, n } = parseOptions(ctx.message.text);
  const reply = ctx.message.reply_to_message;

  // Reply ke dokumen PDF
  if (!body && reply?.document) return summarizeDocument(ctx, reply.document, n);

  const input = body || reply?.text || reply?.caption || '';
  if (!input) return ctx.reply('Gunakan: /ringkas <url atau teks>, atau balas sebuah pesan.\n\nKetik /help untuk bantuan.');

  if (/^https?:\/\/\S+$/i.test(input.trim())) return summarizeUrl(ctx, input.trim(), n);
  return summarizeText(ctx, input, n);
});

bot.command('diskusi', async ctx => {
  const { body, n } = parseOptions(ctx.message.text);
  const reply = ctx.message.reply_to_message;
  const input = body || reply?.text || reply?.caption || '';
  if (!input) return ctx.reply('Gunakan: /diskusi <teks diskusi>, atau balas pesan yang berisi diskusi.');
  return summarizeDiscussionCmd(ctx, input, n);
});

// PDF yang dikirim langsung dengan caption /ringkas
bot.on('document', async ctx => {
  const caption = ctx.message.caption || '';
  if (/^\/ringkas(@\w+)?\b/i.test(caption)) {
    const { n } = parseOptions(caption);
    return summarizeDocument(ctx, ctx.message.document, n);
  }
});

bot.catch((err, ctx) => {
  console.error(`[BOT ERROR] ${ctx.updateType}:`, err);
});

bot.launch().then(() => console.log('✅ Bot summarizer berjalan (polling).'));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
